/*
 * Hero 3D — Clínica de Imagem Village
 * Maquete 3D de uma clínica, 100% em código (Three.js): recepção, sala de ressonância,
 * sala de ultrassom e consultório. Pacientes fazem o check-in, vão até a sala, deitam
 * no equipamento e saem com o resultado online. Salas reagem ao mouse/toque e
 * levam ao WhatsApp. Sem vídeo.
 *
 * Este arquivo é o FONTE. O site carrega public/js/hero3d.bundle.js (gerado com: npm run build).
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import logoUrl from '../public/assets/logo.png'; // embutido no bundle (funciona até via file://)

const C = {
  purple: 0x42204e, violet: 0x7b3fa0, lilac: 0xc9a7e0, lilacSoft: 0xefe6f5,
  scan: 0x2ec5d3, white: 0xfbf9fc, wood: 0xe9dccf, skin: [0xf1c7a5, 0xc68b62, 0x8d5a3b, 0xf5d2b8],
};
const WHATS = 'https://api.whatsapp.com/send?phone=5561996104545&text=';

const ROOMS = {
  A: { nome: 'Ressonância Magnética', desc: 'Articulações, coluna, crânio, abdome e mais.', msg: 'uma Ressonância Magnética', c: [-1.5, -1.5] },
  B: { nome: 'Ultrassom e Doppler', desc: 'Abdome, transvaginal, mamas, tireoide, doppler vascular.', msg: 'um Ultrassom/Doppler', c: [1.5, -1.5] },
  C: { nome: 'Recepção', desc: 'Agendamento rápido e atendimento acolhedor.', msg: 'um atendimento', c: [-1.5, 1.5] },
  D: { nome: 'Consultas', desc: 'Ginecologia, Ortopedia, Angiologia, Nutrição e Clínica Médica.', msg: 'uma consulta', c: [1.5, 1.5] },
};

export function initHero3D(container) {
  // ---------- Capacidades / fallback ----------
  const test = document.createElement('canvas');
  if (!(window.WebGLRenderingContext && (test.getContext('webgl2') || test.getContext('webgl')))) {
    container.classList.add('is-fallback'); return;
  }
  const isTouch = matchMedia('(hover: none)').matches;
  const isSmall = matchMedia('(max-width: 768px)').matches;
  const speed = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0.4 : 1;

  // ---------- Renderer / cena ----------
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, isSmall ? 1.5 : 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.className = 'hero3d__canvas';
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
  const TARGET = new THREE.Vector3(0, 0.15, 0);

  scene.add(new THREE.HemisphereLight(0xffffff, C.lilac, 0.55));
  const sun = new THREE.DirectionalLight(0xffffff, 1.6);
  sun.position.set(4, 8, 5);
  sun.castShadow = true;
  sun.shadow.mapSize.set(isSmall ? 1024 : 2048, isSmall ? 1024 : 2048);
  Object.assign(sun.shadow.camera, { left: -5, right: 5, top: 5, bottom: -5, near: 1, far: 20 });
  sun.shadow.bias = -0.0005;
  scene.add(sun);
  const cursorLight = new THREE.PointLight(C.scan, 4, 6, 2);
  scene.add(cursorLight);

  // ---------- Materiais ----------
  const M = {
    white: new THREE.MeshPhysicalMaterial({ color: C.white, roughness: 0.35, clearcoat: 0.6 }),
    purple: new THREE.MeshPhysicalMaterial({ color: C.purple, roughness: 0.4, clearcoat: 0.6 }),
    violet: new THREE.MeshStandardMaterial({ color: C.violet, roughness: 0.45 }),
    lilac: new THREE.MeshStandardMaterial({ color: C.lilac, roughness: 0.6 }),
    wood: new THREE.MeshStandardMaterial({ color: C.wood, roughness: 0.7 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x2a1633, roughness: 0.4 }),
    glow: new THREE.MeshBasicMaterial({ color: C.scan, toneMapped: false }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xe8dcf2, roughness: 0.05, transparent: true, opacity: 0.28, depthWrite: false }),
  };

  const root = new THREE.Group();
  scene.add(root);
  const pops = []; // animação de entrada: { obj, delay, axis }
  const pop = (obj, delay, axis = 'xyz') => { pops.push({ obj, delay, axis }); return obj; };
  const box = (w, h, d, mat, x, y, z, r = 0.04) => {
    const m = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.01, h / 2.01, d / 2.01)), mat);
    m.position.set(x, y, z);
    return m;
  };

  // ---------- Base / piso ----------
  root.add(pop(box(6.6, 0.36, 6.6, M.white, 0, -0.18, 0, 0.12), 0));
  root.add(pop(box(6.64, 0.06, 6.64, M.purple, 0, -0.3, 0, 0.03), 0));

  // Pisos das salas (também são as áreas de hover)
  const tiles = {};
  const tileColors = { A: 0xf3eef7, B: 0xf3eef7, C: C.lilacSoft, D: 0xf6f2f9 };
  Object.entries(ROOMS).forEach(([k, r]) => {
    const mat = new THREE.MeshStandardMaterial({ color: tileColors[k], roughness: 0.8, emissive: C.scan, emissiveIntensity: 0 });
    const t = new THREE.Mesh(new THREE.BoxGeometry(3.1, 0.03, 3.1), mat);
    t.position.set(r.c[0], 0.015, r.c[1]);
    t.userData.room = k;
    // Moldura luminosa do hover
    const fm = new THREE.MeshBasicMaterial({ color: C.scan, transparent: true, opacity: 0, toneMapped: false });
    [[3.05, 0.04, 0, 1.52], [3.05, 0.04, 0, -1.52], [0.04, 3.05, 1.52, 0], [0.04, 3.05, -1.52, 0]].forEach(([w, d, x, z]) => {
      const b = new THREE.Mesh(new THREE.BoxGeometry(w, 0.02, d), fm);
      b.position.set(x, 0.03, z);
      t.add(b);
    });
    tiles[k] = { mesh: t, frameMat: fm, hover: 0, busy: 0 };
    root.add(pop(t, 0.1));
  });

  // ---------- Paredes ----------
  const walls = new THREE.Group();
  walls.add(box(6.6, 1.5, 0.16, M.white, 0, 0.75, -3.22, 0.05));
  walls.add(box(0.16, 1.5, 6.6, M.white, -3.22, 0.75, 0, 0.05));
  walls.add(box(6.6, 0.06, 0.18, M.purple, 0, 1.5, -3.22, 0.03));
  walls.add(box(0.18, 0.06, 6.6, M.purple, -3.22, 1.5, 0, 0.03));
  const skyMat = new THREE.MeshBasicMaterial({ map: gradientTexture(['#cfe9f2', '#efe6f5']), toneMapped: false });
  [-2.2, -1.1, 0.8, 2.2].forEach((x) => {
    const w = new THREE.Mesh(new THREE.PlaneGeometry(0.85, 0.5), skyMat);
    w.position.set(x, 0.95, -3.13);
    walls.add(w);
  });
  const w2 = new THREE.Mesh(new THREE.PlaneGeometry(0.85, 0.5), skyMat);
  w2.position.set(-3.13, 0.95, -1.5); w2.rotation.y = Math.PI / 2;
  walls.add(w2);
  root.add(pop(walls, 0.15, 'y'));

  // Divisórias de vidro (com vãos de porta)
  const glass = new THREE.Group();
  const glassSeg = (x1, z1, x2, z2) => {
    const alongX = Math.abs(x2 - x1) > 0.01, len = alongX ? Math.abs(x2 - x1) : Math.abs(z2 - z1);
    const cx = (x1 + x2) / 2, cz = (z1 + z2) / 2;
    const p = new THREE.Mesh(new THREE.BoxGeometry(alongX ? len : 0.03, 0.95, alongX ? 0.03 : len), M.glass);
    p.position.set(cx, 0.5, cz);
    glass.add(p,
      box(alongX ? len : 0.06, 0.05, alongX ? 0.06 : len, M.white, cx, 1.0, cz, 0.02),
      box(alongX ? len : 0.06, 0.05, alongX ? 0.06 : len, M.white, cx, 0.03, cz, 0.02));
  };
  glassSeg(0, -3.15, 0, 0.9); glassSeg(0, 1.7, 0, 3.0);
  glassSeg(-3.15, 0, -1.75, 0); glassSeg(-0.85, 0, 0.85, 0); glassSeg(1.75, 0, 3.0, 0);
  root.add(pop(glass, 0.25, 'y'));

  // ---------- Sala A: Ressonância ----------
  const roomA = new THREE.Group();
  const R_OUT = 0.62, R_IN = 0.34, DEPTH = 0.42, GX = -2.25, GY = 0.72, GZ = -1.6;
  const ring = new THREE.Shape().absarc(0, 0, R_OUT, 0, Math.PI * 2);
  ring.holes.push(new THREE.Path().absarc(0, 0, R_IN, 0, Math.PI * 2, true));
  const gGeo = new THREE.ExtrudeGeometry(ring, { depth: DEPTH, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.05, bevelSegments: 4, curveSegments: 48 });
  gGeo.translate(0, 0, -DEPTH / 2);
  const gantry = new THREE.Mesh(gGeo, M.white);
  gantry.rotation.y = Math.PI / 2;
  gantry.position.set(GX, GY, GZ);
  const gantryBand = new THREE.Mesh(new THREE.TorusGeometry(R_OUT + 0.02, 0.025, 10, 64), M.purple);
  gantryBand.rotation.y = Math.PI / 2;
  gantryBand.position.set(GX + DEPTH / 2 + 0.06, GY, GZ);
  const boreGlow = new THREE.Mesh(new THREE.TorusGeometry(R_IN, 0.018, 8, 64), new THREE.MeshBasicMaterial({ color: C.scan, toneMapped: false }));
  boreGlow.rotation.y = Math.PI / 2;
  boreGlow.position.set(GX + DEPTH / 2 + 0.08, GY, GZ);
  const scanMat = new THREE.MeshBasicMaterial({ color: C.scan, transparent: true, opacity: 0, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
  const scanDisc = new THREE.Mesh(new THREE.CircleGeometry(R_IN - 0.02, 40), scanMat);
  scanDisc.rotation.y = Math.PI / 2;
  scanDisc.position.set(GX, GY, GZ);
  const mriTable = new THREE.Group();
  mriTable.add(box(1.35, 0.06, 0.42, M.white, 0, 0, 0, 0.03), box(1.37, 0.02, 0.44, M.purple, 0, -0.035, 0, 0.01));
  mriTable.position.set(-1.45, 0.42, GZ);
  const mriScreenTex = makeCanvasTex(256, 160);
  const screenA = screen(mriScreenTex, 0.48, 0.32);
  screenA.position.set(-0.55, 0.68, -2.6); screenA.rotation.set(-0.2, -0.35, 0);
  roomA.add(gantry, gantryBand, boreGlow, scanDisc, mriTable,
    box(0.6, 0.12, 1.1, M.white, GX, 0.06, GZ),          // base do aparelho
    box(0.4, 0.38, 0.4, M.white, -1.15, 0.19, GZ),       // pedestal da mesa
    box(0.5, 0.48, 0.3, M.white, -0.55, 0.24, -2.75),    // console
    screenA);
  root.add(pop(roomA, 0.4));

  // ---------- Sala B: Ultrassom ----------
  const roomB = new THREE.Group();
  const usTex = makeCanvasTex(256, 192);
  const screenB = screen(usTex, 0.5, 0.38);
  screenB.position.set(1.25, 0.86, -2.6); screenB.rotation.y = 0.35;
  roomB.add(
    box(1.2, 0.32, 0.4, M.white, 1.9, 0.16, -1.7),       // base da maca
    box(1.3, 0.1, 0.5, M.lilac, 1.9, 0.37, -1.7, 0.04),  // colchão
    box(0.25, 0.06, 0.4, M.white, 1.35, 0.44, -1.7, 0.03),
    box(0.36, 0.55, 0.32, M.white, 1.25, 0.28, -2.6),    // aparelho de ultrassom
    box(0.05, 0.25, 0.05, M.white, 1.25, 0.62, -2.6, 0.02),
    screenB, plant(2.85, -2.85));
  root.add(pop(roomB, 0.5));

  // ---------- Sala C: Recepção ----------
  const roomC = new THREE.Group();
  const pcC = box(0.28, 0.2, 0.03, M.dark, -1.9, 0.72, 1.05, 0.01); pcC.rotation.y = 0.3;
  roomC.add(
    box(1.2, 0.55, 0.42, M.white, -1.7, 0.28, 1.2, 0.06),   // balcão
    box(1.22, 0.14, 0.44, M.purple, -1.7, 0.2, 1.2, 0.04),
    box(1.3, 0.04, 0.5, M.wood, -1.7, 0.57, 1.2, 0.02),
    pcC);
  [1.75, 2.2, 2.65].forEach((z) => {
    roomC.add(box(0.42, 0.06, 0.4, M.violet, -2.75, 0.24, z, 0.03), box(0.08, 0.36, 0.4, M.violet, -2.98, 0.4, z, 0.03), box(0.36, 0.22, 0.05, M.white, -2.75, 0.11, z, 0.02));
  });
  // Logo da clínica na parede
  const logoTex = new THREE.TextureLoader().load(logoUrl);
  logoTex.colorSpace = THREE.SRGBColorSpace;
  const logoPlane = new THREE.Mesh(new THREE.PlaneGeometry(1.35, 0.44), new THREE.MeshBasicMaterial({ map: logoTex, transparent: true }));
  logoPlane.position.set(-3.13, 1.05, 2.15); logoPlane.rotation.y = Math.PI / 2;
  // TV de senhas
  const tvTex = makeCanvasTex(256, 144);
  const tv = screen(tvTex, 0.7, 0.42);
  tv.position.set(-3.1, 0.95, 0.75); tv.rotation.y = Math.PI / 2;
  roomC.add(logoPlane, tv, box(0.9, 0.02, 0.5, M.purple, -0.2, 0.04, 2.85, 0.01), plant(-2.85, 0.35));
  root.add(pop(roomC, 0.6));

  // ---------- Sala D: Consultório ----------
  const roomD = new THREE.Group();
  const ecgTex = makeCanvasTex(256, 160);
  const screenD = screen(ecgTex, 0.46, 0.3);
  screenD.position.set(1.95, 0.72, 1.62); screenD.rotation.y = -0.7;
  const crossDecal = crossMesh(0.16, 0.04, M.violet); crossDecal.position.set(2.4, 0.45, 0.49);
  roomD.add(
    box(0.55, 0.05, 1.0, M.wood, 1.95, 0.5, 1.3, 0.02),     // mesa
    box(0.5, 0.48, 0.05, M.white, 1.95, 0.24, 0.85, 0.02),
    box(0.5, 0.48, 0.05, M.white, 1.95, 0.24, 1.75, 0.02),
    screenD,
    box(0.36, 0.05, 0.36, M.purple, 2.55, 0.3, 1.3, 0.03),  // cadeira do médico
    box(0.06, 0.4, 0.36, M.purple, 2.75, 0.5, 1.3, 0.03),
    box(0.06, 0.28, 0.06, M.white, 2.55, 0.14, 1.3, 0.02),
    box(0.36, 0.05, 0.36, M.lilac, 1.25, 0.28, 1.3, 0.03),  // cadeira do paciente
    box(0.06, 0.26, 0.06, M.white, 1.25, 0.13, 1.3, 0.02),
    box(0.8, 0.7, 0.35, M.white, 2.4, 0.35, 0.3),           // armário
    crossDecal, plant(2.85, 2.85));
  root.add(pop(roomD, 0.7));

  // ---------- Placa da clínica (cruz girando) ----------
  const sign = new THREE.Group();
  const halo = new THREE.Mesh(new THREE.TorusGeometry(0.48, 0.022, 10, 80), new THREE.MeshBasicMaterial({ color: C.scan, toneMapped: false }));
  sign.add(crossMesh(0.55, 0.16, M.purple), halo);
  sign.position.set(-3.0, 2.35, -3.0);
  root.add(pop(sign, 1.0));

  // ---------- Pessoas ----------
  function person(bodyColor, kind, skin) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.26, 6, 14),
      kind === 'doctor' ? M.white : new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.5 }));
    body.position.y = 0.25;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.1, 20, 16), new THREE.MeshStandardMaterial({ color: skin, roughness: 0.6 }));
    head.position.y = 0.6;
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.106, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2.1),
      new THREE.MeshStandardMaterial({ color: 0x2b1d18, roughness: 0.7 }));
    hair.position.y = 0.61; hair.rotation.x = -0.35;
    const inner = new THREE.Group(); // escala dos bonecos (mais legíveis em telas pequenas)
    inner.scale.setScalar(1.25);
    g.add(inner);
    inner.add(body, head, hair);
    if (kind === 'doctor') {
      const steth = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.012, 6, 20, Math.PI * 1.3), M.glow);
      steth.position.set(0, 0.42, 0.06); steth.rotation.set(0.5, 0, Math.PI * 1.35);
      const badge = crossMesh(0.05, 0.014, M.violet); badge.position.set(0.06, 0.38, 0.115);
      const scrubs = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.1, 4, 10), new THREE.MeshStandardMaterial({ color: bodyColor }));
      scrubs.position.y = 0.12;
      inner.add(steth, badge, scrubs);
    }
    g.userData = { body, head, phase: Math.random() * 6 };
    root.add(g);
    return g;
  }

  // Equipe fixa + paciente na sala de espera
  const staff = [
    { g: person(C.purple, 'staff', C.skin[1]), x: -1.7, z: 0.72, ry: 0 },                         // recepcionista
    { g: person(C.scan, 'doctor', C.skin[0]), x: 0.85, z: -1.95, ry: 1.0 },                       // médica do ultrassom
    { g: person(C.violet, 'doctor', C.skin[2]), x: 2.55, z: 1.3, ry: -Math.PI / 2, sit: 0.1 },    // médico do consultório
    { g: person(C.scan, 'doctor', C.skin[3]), x: -0.55, z: -2.25, ry: Math.PI },                  // técnico da RM
    { g: person(0xf2a7b5, 'patient', C.skin[1]), x: -2.72, z: 2.2, ry: Math.PI / 2, sit: 0.1 },   // paciente esperando
  ];
  staff.forEach((s, i) => {
    s.g.position.set(s.x, -(s.sit || 0), s.z);
    s.g.rotation.y = s.ry;
    pop(s.g, 0.9 + i * 0.06);
  });

  // Rotas dos pacientes [x, z]. w = espera (s), lie = deita no equipamento, b = balão
  const S = [-0.4, 3.0];
  const checkin = { p: [-1.6, 1.85], w: 1.6, face: Math.PI, b: ['ok', 'Check-in realizado'] };
  const exitB = ['res', 'Resultado online'];
  const ROUTES = [
    [{ p: S }, checkin, { p: [-0.4, 1.5] }, { p: [0.4, 1.3] }, { p: [1.3, 0.7] }, { p: [1.3, -0.4] },
      { p: [1.6, -1.15], w: 5, room: 'B', b: ['live', 'Ultrassom em andamento'], lie: { at: [2.5, 0.57, -1.7] } },
      { p: [1.3, -0.4] }, { p: [1.3, 0.7] }, { p: [0.7, 2.1] }, { p: [0.6, 3.0], end: true, b: exitB }],
    [{ p: S }, checkin, { p: [-0.7, 1.0] }, { p: [-1.3, 0.45] }, { p: [-1.3, -0.5] },
      { p: [-0.95, -1.15], w: 6.5, room: 'A', b: ['live', 'Ressonância em andamento'], lie: { at: [-0.8, 0.6, GZ], slide: -0.62 } },
      { p: [-1.3, -0.5] }, { p: [-1.3, 0.45] }, { p: [-0.6, 1.0] }, { p: [0.0, 2.2] }, { p: [0.4, 3.0], end: true, b: exitB }],
    [{ p: S }, checkin, { p: [-0.4, 1.5] }, { p: [0.4, 1.3] },
      { p: [1.22, 1.3], w: 5, room: 'D', sit: 0.1, face: Math.PI / 2, b: ['doc', 'Consulta com especialista'] },
      { p: [1.0, 2.2] }, { p: [0.8, 3.0], end: true, b: exitB }],
  ];
  const outfit = [[0x6fb7e8, C.skin[0]], [0xf0b14a, C.skin[2]], [0x8fd1a8, C.skin[1]]];
  const walkers = [0, 1, 2].map((i) => {
    const g = person(outfit[i][0], 'patient', outfit[i][1]);
    g.scale.setScalar(0.001);
    return { g, route: ROUTES[i], ri: i, idx: 0, state: 'spawn', timer: 1.4 + i * 2.6, pos: new THREE.Vector2(...S), wait: 0, waitT: 0, fade: 0 };
  });

  // ---------- Partículas: cruzes subindo ----------
  const P = isSmall ? 18 : 34;
  const crossGeo = mergeGeometries([new THREE.BoxGeometry(0.09, 0.025, 0.025), new THREE.BoxGeometry(0.025, 0.09, 0.025)]);
  const crosses = new THREE.InstancedMesh(crossGeo, new THREE.MeshBasicMaterial({ color: C.violet, transparent: true, opacity: 0.55 }), P);
  const cData = Array.from({ length: P }, () => ({ x: (Math.random() - 0.5) * 7.5, y: Math.random() * 3.5, z: (Math.random() - 0.5) * 7.5, s: 0.15 + Math.random() * 0.25, r: Math.random() * 6 }));
  root.add(crosses);

  // Sombras
  root.traverse((o) => {
    if (o.isMesh && o.material !== M.glass && !o.material.isMeshBasicMaterial) { o.castShadow = true; o.receiveShadow = true; }
  });

  // ---------- Overlay HTML: tooltip + balões ----------
  const tip = document.createElement('div');
  tip.className = 'hero3d__tip';
  container.appendChild(tip);
  const bubbles = [];
  function bubble(kind, text, follow) {
    const el = document.createElement('div');
    el.className = `hero3d__bubble hero3d__bubble--${kind}`;
    el.innerHTML = `<i></i>${text}`;
    container.appendChild(el);
    bubbles.push({ el, follow, life: 2.6 });
  }

  // ---------- Interação ----------
  const pointer = new THREE.Vector2(), look = new THREE.Vector2();
  let inside = false, dragging = false, dragOffset = 0, dragVel = 0, lastX = 0, downX = 0, downY = 0;
  let hovered = null;
  const raycaster = new THREE.Raycaster();
  const tileMeshes = Object.values(tiles).map((tl) => tl.mesh);
  const el = renderer.domElement;
  const setPointer = (e) => {
    const r = container.getBoundingClientRect();
    pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  };
  // Só os pisos entram no raycast: a sala inteira vira a área de hover
  const pick = () => { raycaster.setFromCamera(pointer, camera); return raycaster.intersectObjects(tileMeshes, false)[0]?.object.userData.room || null; };
  el.addEventListener('pointermove', (e) => {
    setPointer(e); inside = true;
    if (dragging) { dragVel = (e.clientX - lastX) * 0.006; dragOffset += dragVel; lastX = e.clientX; }
  });
  el.addEventListener('pointerleave', () => { inside = false; if (!isTouch) hovered = null; });
  el.addEventListener('pointerdown', (e) => { setPointer(e); dragging = true; lastX = downX = e.clientX; downY = e.clientY; dragVel = 0; });
  el.addEventListener('pointercancel', () => { dragging = false; }); // rolagem vertical no mobile
  addEventListener('pointerup', (e) => {
    if (!dragging) return;
    dragging = false;
    if (Math.hypot(e.clientX - downX, e.clientY - downY) > 8 || e.target !== el) return;
    const room = pick();
    // Desktop: clique agenda. Mobile: 1º toque mostra a sala, 2º agenda.
    if (room && (!isTouch || hovered === room)) {
      open(WHATS + encodeURIComponent(`Olá! Gostaria de agendar ${ROOMS[room].msg}.`), '_blank', 'noopener');
    }
    hovered = room;
  });

  // ---------- Layout ----------
  function resize() {
    const w = container.clientWidth, h = container.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    const tanFull = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * 2;
    camera.userData.dist = Math.max(7.4 / tanFull, 10.2 / (tanFull * camera.aspect));
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(container);
  resize();

  // ---------- Simulação ----------
  let t = 0, introT = 0, screenAcc = 0, queue = 41;
  const camDir = new THREE.Vector3(1, 1.05, 1.15).normalize();
  const v3 = new THREE.Vector3();
  const tmpObj = new THREE.Object3D();
  const INTRO = 2.2;

  function updateWalker(w, dt) {
    const g = w.g, u = g.userData;
    if (w.state === 'spawn') {
      w.timer -= dt;
      if (w.timer > 0) return;
      w.idx = 0; w.pos.set(...w.route[0].p); w.state = 'walk'; w.fade = 0;
    }
    if (w.state === 'gone') {
      w.fade = Math.max(0, w.fade - dt * 3);
      g.scale.setScalar(Math.max(easeOutBack(w.fade), 0.001));
      if (w.fade <= 0) {
        w.ri = (w.ri + 1) % ROUTES.length; w.route = ROUTES[w.ri];
        w.state = 'spawn'; w.timer = 1 + Math.random() * 1.5;
      }
      return;
    }
    w.fade = Math.min(1, w.fade + dt * 2.5);
    g.scale.setScalar(Math.max(easeOutBack(w.fade), 0.001));
    const step = w.route[w.idx];

    if (w.state === 'walk') {
      const [tx, tz] = step.p;
      const dx = tx - w.pos.x, dz = tz - w.pos.y, d = Math.hypot(dx, dz), v = 0.95 * dt;
      if (d > v) {
        w.pos.x += (dx / d) * v; w.pos.y += (dz / d) * v;
        g.rotation.y = lerpAngle(g.rotation.y, Math.atan2(dx, dz), 0.2);
        u.phase += dt * 11;
      } else {
        w.pos.set(tx, tz);
        if (step.b) bubble(step.b[0], step.b[1], g);
        if (step.end) { w.state = 'gone'; return; }
        if (step.w) { w.state = 'wait'; w.wait = step.w; w.waitT = 0; } else w.idx++;
      }
      g.position.set(w.pos.x, Math.abs(Math.sin(u.phase)) * 0.045, w.pos.y);
      g.rotation.z = Math.sin(u.phase) * 0.06;
      return;
    }

    // Esperando: no balcão, sentado ou deitado no equipamento
    w.waitT += dt;
    const k = smooth(Math.min(1, w.waitT / 0.6)) * smooth(clamp01((w.wait - w.waitT) / 0.6));
    if (step.room) tiles[step.room].busy = Math.max(tiles[step.room].busy, k);
    if (step.lie) {
      const prog = w.waitT / w.wait;
      const slide = step.lie.slide ? step.lie.slide * smooth(clamp01((prog - 0.15) / 0.15)) * smooth(clamp01((0.88 - prog) / 0.12)) : 0;
      if (step.lie.slide) mriTable.position.x = -1.45 + slide;
      const [lx, ly, lz] = step.lie.at;
      g.position.set(lerp(w.pos.x, lx + slide, k), lerp(0, ly, k), lerp(w.pos.y, lz, k));
      g.rotation.y = lerpAngle(g.rotation.y, 0, 0.15);
      g.rotation.z = k * Math.PI / 2;
      u.body.scale.z = 1 + Math.sin(t * 2) * 0.03 * k; // respiração
    } else {
      g.position.set(w.pos.x, -(step.sit || 0) * k + Math.sin(t * 2 + u.phase) * 0.01, w.pos.y);
      g.rotation.y = lerpAngle(g.rotation.y, step.face ?? Math.PI, 0.12);
      g.rotation.z = 0;
    }
    if (w.waitT >= w.wait) { w.state = 'walk'; w.idx++; }
  }

  function update(dt) {
    t += dt;
    introT = Math.min(introT + dt / INTRO, 1);

    // Entrada: cada parte "brota" em sequência
    pops.forEach(({ obj, delay, axis }) => {
      const s = Math.max(easeOutBack(clamp01((introT * INTRO - delay) / 0.55)), 0.001);
      if (axis === 'y') obj.scale.set(1, s, 1); else obj.scale.setScalar(s);
    });

    // Parallax do mouse + arrasto com inércia
    if (!dragging) { dragVel *= 0.93; dragOffset += dragVel; dragOffset *= 0.985; }
    const auto = Math.sin(t * 0.22) * 0.3;
    const tx = inside && !isTouch ? pointer.x : auto, ty = inside && !isTouch ? pointer.y : 0;
    look.x += (tx - look.x) * 0.05; look.y += (ty - look.y) * 0.05;
    root.rotation.y = look.x * 0.28 + dragOffset;
    root.rotation.x = -look.y * 0.05;
    cursorLight.position.set(look.x * 3.5, 1.8, 2 - look.y * 2);

    if (!isTouch && inside && !dragging) {
      hovered = pick();
      el.style.cursor = hovered ? 'pointer' : 'grab';
    }

    Object.values(tiles).forEach((tl) => { tl.busy = 0; });
    walkers.forEach((w) => updateWalker(w, dt));
    if (!walkers.some((w) => w.state === 'wait' && w.route[w.idx].lie?.slide)) {
      mriTable.position.x += (-1.45 - mriTable.position.x) * 0.1;
    }

    // Salas: hover + "ocupada"
    Object.entries(tiles).forEach(([k, tl]) => {
      tl.hover += ((hovered === k ? 1 : 0) - tl.hover) * 0.15;
      tl.mesh.material.emissiveIntensity = tl.hover * 0.35 + tl.busy * (0.12 + Math.sin(t * 5) * 0.05);
      tl.frameMat.opacity = Math.max(tl.hover, tl.busy * 0.5);
    });

    // Equipe: respiração e olhar
    staff.forEach((s, i) => {
      const u = s.g.userData;
      u.body.scale.y = 1 + Math.sin(t * 2 + i) * 0.02;
      u.head.rotation.y = Math.sin(t * 0.7 + i * 2) * 0.5;
    });
    staff[1].g.rotation.y = 1.0 + Math.sin(t * 1.3) * 0.25 * (tiles.B.busy > 0.5 ? 1 : 0.2);

    // Ressonância: brilho e feixe quando ocupada
    const busyA = tiles.A.busy;
    boreGlow.material.color.setHex(C.scan).multiplyScalar(0.7 + busyA * 1.2 + Math.sin(t * 6) * 0.2 * busyA);
    scanDisc.position.x = GX + Math.sin(t * 3) * 0.2;
    scanMat.opacity = busyA * (0.35 + Math.sin(t * 9) * 0.08);

    sign.rotation.y = t * 0.9;
    sign.position.y = 2.35 + Math.sin(t * 1.4) * 0.08;
    halo.rotation.x = Math.sin(t * 1.1) * 0.4;

    cData.forEach((c, i) => {
      c.y += c.s * dt; if (c.y > 3.6) c.y = 0;
      tmpObj.position.set(c.x, c.y, c.z);
      tmpObj.rotation.set(0, c.r + t * c.s * 2, 0);
      tmpObj.scale.setScalar(Math.sin((c.y / 3.6) * Math.PI) * 1.2 + 0.01);
      tmpObj.updateMatrix(); crosses.setMatrixAt(i, tmpObj.matrix);
    });
    crosses.instanceMatrix.needsUpdate = true;

    // Telas (15 fps bastam)
    screenAcc += dt;
    if (screenAcc > 1 / 15) {
      screenAcc = 0;
      drawUS(usTex, t, tiles.B.busy);
      drawECG(ecgTex, t);
      drawMRI(mriScreenTex, t, busyA);
      const q = 41 + Math.floor(t / 4) % 58;
      if (q !== queue) { queue = q; }
      drawTV(tvTex, queue, t);
    }
  }

  function project(obj, yOff) {
    obj.getWorldPosition(v3); v3.y += yOff;
    v3.project(camera);
    return [(v3.x * 0.5 + 0.5) * container.clientWidth, (-v3.y * 0.5 + 0.5) * container.clientHeight];
  }

  const roomAnchor = new THREE.Object3D();
  root.add(roomAnchor);
  function updateOverlay(dt) {
    if (hovered) {
      const r = ROOMS[hovered];
      roomAnchor.position.set(r.c[0], 0, r.c[1]);
      const [x, y] = project(roomAnchor, 1.2);
      if (tip.dataset.room !== hovered) {
        tip.dataset.room = hovered;
        tip.innerHTML = `<strong>${r.nome}</strong><span>${r.desc}</span><em>${isTouch ? 'Toque de novo para agendar' : 'Clique para agendar'} →</em>`;
      }
      const cx = clamp(x, 120, container.clientWidth - 120);
      tip.style.transform = `translate(${cx}px, ${Math.max(y, tip.offsetHeight + 12)}px) translate(-50%, -100%)`;
      tip.classList.add('is-on');
    } else { tip.classList.remove('is-on'); tip.dataset.room = ''; }

    for (let i = bubbles.length - 1; i >= 0; i--) {
      const b = bubbles[i];
      b.life -= dt;
      const [x, y] = project(b.follow, 0.95);
      const half = b.el.offsetWidth / 2 + 6; // mantém o balão dentro do quadro
      b.el.style.transform = `translate(${clamp(x, half, container.clientWidth - half)}px, ${y}px) translate(-50%, -100%)`;
      b.el.classList.toggle('is-on', b.life > 0.35 && b.life < 2.5);
      if (b.life <= 0) { b.el.remove(); bubbles.splice(i, 1); }
    }
  }

  function render() {
    const dist = camera.userData.dist * (1.3 - 0.3 * easeOutCubic(introT));
    camera.position.copy(camDir).multiplyScalar(dist).add(TARGET);
    camera.position.y += Math.sin(t * 0.4) * 0.06;
    camera.lookAt(TARGET);
    renderer.render(scene, camera);
  }

  // Debug p/ screenshots: ?shot=SEGUNDOS&room=A — avança a simulação e congela
  const qs = new URLSearchParams(location.search);
  const frozen = qs.has('shot');
  if (frozen) {
    const target = parseFloat(qs.get('shot'));
    while (t < target) { update(1 / 30); for (const b of bubbles) b.life -= 1 / 30; }
    bubbles.filter((b) => b.life <= 0).forEach((b) => b.el.remove());
    bubbles.splice(0, bubbles.length, ...bubbles.filter((b) => b.life > 0));
    hovered = qs.get('room');
  }

  // ---------- Loop (pausa fora da tela) ----------
  const clock = new THREE.Clock();
  let running = false, raf = 0;
  function frame() {
    raf = requestAnimationFrame(frame);
    const dt = frozen ? 0 : Math.min(clock.getDelta(), 0.05) * speed;
    if (!frozen) update(dt);
    render(); updateOverlay(dt);
  }
  const start = () => { if (!running) { running = true; clock.getDelta(); frame(); } };
  const stop = () => { running = false; cancelAnimationFrame(raf); };
  new IntersectionObserver(([e]) => (e.isIntersecting && !document.hidden ? start() : stop()), { threshold: 0.05 }).observe(container);
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));

  container.classList.add('is-ready');
}

// ---------- Telas (canvas) ----------
function drawUS(c, t, busy) {
  const x = c.ctx, W = 256, H = 192;
  x.fillStyle = '#0d0710'; x.fillRect(0, 0, W, H);
  x.save();
  x.beginPath(); x.moveTo(W / 2, 14); x.arc(W / 2, 14, 168, Math.PI * 0.28, Math.PI * 0.72); x.closePath(); x.clip();
  x.fillStyle = '#1b1320'; x.fillRect(0, 0, W, H);
  for (let i = 0; i < 520; i++) {
    const g = 60 + Math.random() * 120 * (0.4 + busy * 0.6);
    x.fillStyle = `rgba(${g},${g},${g + 10},${0.25 + Math.random() * 0.4})`;
    x.fillRect(Math.random() * W, 14 + Math.random() * H, 2 + Math.random() * 3, 1.5);
  }
  x.fillStyle = '#060308'; // estrutura (órgão) se movendo
  x.beginPath(); x.ellipse(W / 2 + Math.sin(t * 1.3) * 18, 110 + Math.cos(t) * 6, 34 + Math.sin(t * 3) * 4, 22, 0.2, 0, Math.PI * 2); x.fill();
  x.strokeStyle = 'rgba(220,220,230,0.5)'; x.lineWidth = 2; x.stroke();
  x.restore();
  x.fillStyle = '#2ec5d3'; x.font = '700 16px Inter, sans-serif';
  x.fillText(busy > 0.3 ? '● AO VIVO' : 'US · VILLAGE', 10, 22);
  c.tex.needsUpdate = true;
}
function drawECG(c, t) {
  const x = c.ctx, W = 256, H = 160;
  x.fillStyle = '#1f0f27'; x.fillRect(0, 0, W, H);
  x.strokeStyle = 'rgba(201,167,224,0.12)'; x.lineWidth = 1;
  for (let i = 0; i < W; i += 20) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i, H); x.stroke(); }
  x.strokeStyle = '#2ec5d3'; x.lineWidth = 3; x.shadowColor = '#2ec5d3'; x.shadowBlur = 8;
  x.beginPath();
  for (let i = 0; i <= W; i += 2) {
    const ph = ((i / W) * 2 + t * 1.2) % 1;
    let v = 0;
    if (ph > 0.2 && ph < 0.23) v = -12; else if (ph > 0.23 && ph < 0.27) v = 48; else if (ph > 0.27 && ph < 0.3) v = -18;
    else if (ph > 0.45 && ph < 0.55) v = Math.sin((ph - 0.45) * Math.PI * 10) * 10;
    i ? x.lineTo(i, 100 - v) : x.moveTo(i, 100 - v);
  }
  x.stroke(); x.shadowBlur = 0;
  x.fillStyle = '#fff'; x.font = '800 26px Inter, sans-serif';
  x.fillText(`${72 + Math.round(Math.sin(t * 0.5) * 3)} bpm`, 12, 34);
  c.tex.needsUpdate = true;
}
function drawMRI(c, t, busy) {
  const x = c.ctx, W = 256, H = 160;
  x.fillStyle = '#1f0f27'; x.fillRect(0, 0, W, H);
  x.save(); x.translate(80, 84); // "corte" do crânio
  for (let r = 58; r > 6; r -= 7) {
    const g = 90 + (58 - r) * 2.4 + Math.sin(t * 3 + r) * 12 * busy;
    x.fillStyle = `rgb(${g},${g - 10},${g + 15})`;
    x.beginPath(); x.ellipse(0, 0, r * 0.82, r, 0, 0, Math.PI * 2); x.fill();
  }
  x.restore();
  const on = busy > 0.05;
  x.fillStyle = 'rgba(46,197,211,0.7)'; x.fillRect(22, 26 + (on ? (t * 0.25) % 1 : 0) * 116, 116, 2);
  x.fillStyle = '#c9a7e0'; x.font = '700 15px Inter, sans-serif'; x.fillText('RM', 160, 40);
  x.fillStyle = '#fff'; x.font = '800 20px Inter, sans-serif'; x.fillText(on ? 'Escaneando' : 'Pronto', 160, 70);
  x.fillStyle = 'rgba(255,255,255,0.15)'; x.fillRect(160, 96, 80, 10);
  x.fillStyle = '#2ec5d3'; x.fillRect(160, 96, 80 * (on ? (t * 0.3) % 1 : 1), 10);
  c.tex.needsUpdate = true;
}
function drawTV(c, n, t) {
  const x = c.ctx, W = 256, H = 144;
  const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#42204e'); g.addColorStop(1, '#7b3fa0');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.textAlign = 'center';
  x.fillStyle = '#c9a7e0'; x.font = '700 18px Inter, sans-serif'; x.fillText('SENHA', W / 2, 36);
  x.fillStyle = '#fff'; x.font = '800 64px Inter, sans-serif';
  x.globalAlpha = 0.75 + Math.sin(t * 6) * 0.25;
  x.fillText(String(n).padStart(3, '0'), W / 2, 104);
  x.globalAlpha = 1; x.textAlign = 'left';
  c.tex.needsUpdate = true;
}

// ---------- Helpers ----------
function screen(canvasTex, w, h) {
  const g = new THREE.Group();
  const frame = new THREE.Mesh(new RoundedBoxGeometry(w, h, 0.04, 2, 0.015), new THREE.MeshStandardMaterial({ color: 0x2a1633, roughness: 0.4 }));
  const disp = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.05, h - 0.05), new THREE.MeshBasicMaterial({ map: canvasTex.tex, toneMapped: false }));
  disp.position.z = 0.021;
  g.add(frame, disp);
  return g;
}
function crossMesh(size, thick, mat) {
  const s = size / 2, k = thick / 2;
  const sh = new THREE.Shape();
  sh.moveTo(-k, s); sh.lineTo(k, s); sh.lineTo(k, k); sh.lineTo(s, k); sh.lineTo(s, -k); sh.lineTo(k, -k);
  sh.lineTo(k, -s); sh.lineTo(-k, -s); sh.lineTo(-k, -k); sh.lineTo(-s, -k); sh.lineTo(-s, k); sh.lineTo(-k, k); sh.closePath();
  const geo = new THREE.ExtrudeGeometry(sh, { depth: thick * 0.6, bevelEnabled: true, bevelThickness: thick * 0.15, bevelSize: thick * 0.12, bevelSegments: 3 });
  geo.center();
  return new THREE.Mesh(geo, mat);
}
function plant(x, z) {
  const g = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.1, 0.24, 20), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 }));
  pot.position.y = 0.12;
  g.add(pot);
  const leaf = new THREE.MeshStandardMaterial({ color: 0x5fb59b, roughness: 0.6, flatShading: true });
  [[0, 0.42, 0, 0.17], [0.08, 0.34, 0.05, 0.12], [-0.07, 0.36, -0.05, 0.12]].forEach(([lx, ly, lz, r]) => {
    const s = new THREE.Mesh(new THREE.IcosahedronGeometry(r, 1), leaf);
    s.position.set(lx, ly, lz);
    g.add(s);
  });
  g.position.set(x, 0, z);
  return g;
}
function makeCanvasTex(w, h) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return { ctx: c.getContext('2d'), tex };
}
function gradientTexture(stops) {
  const c = document.createElement('canvas'); c.width = 4; c.height = 64;
  const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, 64);
  stops.forEach((s, i) => g.addColorStop(i / (stops.length - 1), s));
  x.fillStyle = g; x.fillRect(0, 0, 4, 64);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const clamp01 = (v) => clamp(v, 0, 1);
const lerp = (a, b, k) => a + (b - a) * k;
const smooth = (x) => x * x * (3 - 2 * x);
const easeOutCubic = (x) => 1 - (1 - x) ** 3;
function easeOutBack(x) { x = clamp01(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2; }
function lerpAngle(a, b, k) { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return a + d * k; }
