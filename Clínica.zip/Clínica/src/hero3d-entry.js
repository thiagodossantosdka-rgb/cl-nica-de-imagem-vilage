// Ponto de entrada do bundle (npm run build -> public/js/hero3d.bundle.js)
import { initHero3D } from './hero3d.js';

const stage = document.getElementById('hero3d');
try { initHero3D(stage); } catch (e) { console.error(e); stage.classList.add('is-fallback'); }
