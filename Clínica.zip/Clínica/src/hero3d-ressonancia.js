// Versão anterior da cena (equipamento de ressonância). Para usá-la, importe este arquivo em hero3d-entry.js.
/*
 * Hero 3D — Clínica de Imagem Village
 * Cena 100% em código (Three.js): equipamento de ressonância, mesa com paciente,
 * feixe de varredura, monitor com ECG ao vivo e "chips" de exames interativos.
 * Sem vídeo: ~170 KB (gzip) de biblioteca + este arquivo.
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const COLORS = {
  purple: 0x42204e,
  violet: 0x7b3fa0,
  lilac: 0xc9a7e0,
  scan: 0x2ec5d3,
  white: 0xf7f4fa,
};

const EXAMS = [
  { id: 'us', sigla: 'US', nome: 'Ultrassom', desc: 'Abdome, transvaginal, mamas, tireoide e mais.' },
  { id: 'dp', sigla: 'DP', nome: 'Doppler', desc: 'Membros, carótidas, obstétrico, tireoide e mais.' },
  { id: 'mg', sigla: 'MG', nome: 'Mamografia', desc: 'Rastreamento e diagnóstico da saúde das mamas.' },
  { id: 'do', sigla: 'DO', nome: 'Densitometria', desc: 'Avaliação da massa óssea e risco de osteoporose.' },
  { id: 'rm', sigla: 'RM', nome: 'Ressonância', desc: 'Articulações, coluna, crânio, abdome e mais.' },
];

const WHATS = 'https://api.whatsapp.com/send?phone=5561996104545&text=';

export function initHero3D(container) {
  // ---------- Capacidades / fallback ----------
  const testCanvas = document.createElement('canvas');
  const hasGL = !!(window.WebGLRenderingContext &&
    (testCanvas.getContext('webgl2') || testCanvas.getContext('webgl')));
  if (!hasGL) { container.classList.add('is-fallback'); return; }

  const isTouch = matchMedia('(hover: none)').matches;
  const isSmall = matchMedia('(max-width: 768px)').matches;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const speed = reduced ? 0.35 : 1;

  // ---------- Renderer ----------
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSmall ? 1.5 : 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.domElement.className = 'hero3d__canvas';
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
  const CAM_TARGET = new THREE.Vector3(0, -0.1, 0);

  // ---------- Luzes ----------
  scene.add(new THREE.HemisphereLight(0xffffff, COLORS.lilac, 0.6));
  const key = new THREE.DirectionalLight(0xffffff, 1.4);
  key.position.set(4, 6, 5);
  scene.add(key);
  const cursorLight = new THREE.PointLight(COLORS.scan, 6, 7, 2);
  cursorLight.position.set(0, 1, 2.5);
  scene.add(cursorLight);

  // ---------- Materiais ----------
  const shellMat = new THREE.MeshPhysicalMaterial({
    color: COLORS.white, roughness: 0.28, metalness: 0.05, clearcoat: 1, clearcoatRoughness: 0.15,
  });
  const purpleMat = new THREE.MeshPhysicalMaterial({
    color: COLORS.purple, roughness: 0.35, metalness: 0.2, clearcoat: 0.6,
  });
  const boreMat = new THREE.MeshStandardMaterial({ color: 0xe9e2f0, roughness: 0.6, side: THREE.BackSide });
  const glowMat = new THREE.MeshBasicMaterial({ color: COLORS.scan, toneMapped: false });

  // Grupo raiz (gira com o mouse)
  const root = new THREE.Group();
  scene.add(root);

  // ---------- Equipamento de ressonância ----------
  const gantry = new THREE.Group();
  root.add(gantry);

  const R_OUT = 1.55, R_IN = 0.92, DEPTH = 0.85;
  const ringShape = new THREE.Shape().absarc(0, 0, R_OUT, 0, Math.PI * 2, false);
  ringShape.holes.push(new THREE.Path().absarc(0, 0, R_IN, 0, Math.PI * 2, true));
  const shellGeo = new THREE.ExtrudeGeometry(ringShape, {
    depth: DEPTH, bevelEnabled: true, bevelThickness: 0.14, bevelSize: 0.12, bevelSegments: 6, curveSegments: 72,
  });
  shellGeo.translate(0, 0, -DEPTH / 2);
  const shell = new THREE.Mesh(shellGeo, shellMat);
  gantry.add(shell);

  // Interior do túnel
  const bore = new THREE.Mesh(new THREE.CylinderGeometry(R_IN, R_IN, DEPTH + 0.3, 64, 1, true), boreMat);
  bore.rotation.x = Math.PI / 2;
  gantry.add(bore);

  // Faixa roxa da marca
  const band = new THREE.Mesh(new THREE.TorusGeometry(R_OUT + 0.06, 0.05, 16, 120), purpleMat);
  band.position.z = DEPTH / 2 + 0.05;
  gantry.add(band);

  // Anéis de luz do túnel (frente e trás)
  const boreGlowF = new THREE.Mesh(new THREE.TorusGeometry(R_IN - 0.01, 0.022, 12, 120), glowMat.clone());
  boreGlowF.position.z = DEPTH / 2 + 0.14;
  const boreGlowB = boreGlowF.clone();
  boreGlowB.material = glowMat.clone();
  boreGlowB.position.z = -DEPTH / 2 - 0.14;
  gantry.add(boreGlowF, boreGlowB);

  // LEDs em "loading" na face frontal
  const LED_COUNT = 56;
  const leds = new THREE.InstancedMesh(
    new THREE.SphereGeometry(0.028, 10, 10),
    new THREE.MeshBasicMaterial({ toneMapped: false }),
    LED_COUNT,
  );
  const tmpObj = new THREE.Object3D();
  const tmpColor = new THREE.Color();
  const LED_IDLE = new THREE.Color(COLORS.lilac).multiplyScalar(0.35);
  const LED_HOT = new THREE.Color(COLORS.scan).multiplyScalar(1.6);
  for (let i = 0; i < LED_COUNT; i++) {
    const a = (i / LED_COUNT) * Math.PI * 2;
    tmpObj.position.set(Math.cos(a) * 1.24, Math.sin(a) * 1.24, DEPTH / 2 + 0.15);
    tmpObj.updateMatrix();
    leds.setMatrixAt(i, tmpObj.matrix);
    leds.setColorAt(i, tmpColor.set(COLORS.lilac));
  }
  gantry.add(leds);

  // Base do equipamento
  const base = new THREE.Mesh(new RoundedBoxGeometry(2.3, 0.5, 1.25, 4, 0.12), shellMat);
  base.position.set(0, -1.55, 0);
  gantry.add(base);
  const baseStripe = new THREE.Mesh(new RoundedBoxGeometry(2.32, 0.08, 1.27, 2, 0.03), purpleMat);
  baseStripe.position.set(0, -1.38, 0);
  gantry.add(baseStripe);

  // ---------- Mesa + paciente ----------
  const tableRig = new THREE.Group();
  root.add(tableRig);

  const pedestal = new THREE.Mesh(new RoundedBoxGeometry(0.8, 1.0, 0.9, 4, 0.1), shellMat);
  pedestal.position.set(0, -1.3, 2.25);
  root.add(pedestal);

  const sled = new THREE.Group(); // parte que desliza
  tableRig.add(sled);
  const tableTop = new THREE.Mesh(new RoundedBoxGeometry(0.95, 0.14, 2.9, 4, 0.06), shellMat);
  tableTop.position.y = -0.62;
  sled.add(tableTop);
  const tableStripe = new THREE.Mesh(new RoundedBoxGeometry(0.97, 0.04, 2.92, 2, 0.02), purpleMat);
  tableStripe.position.y = -0.7;
  sled.add(tableStripe);

  const patientMat = new THREE.MeshPhysicalMaterial({
    color: COLORS.lilac, roughness: 0.25, transmission: 0.35, thickness: 0.5,
    transparent: true, opacity: 0.92, clearcoat: 1,
  });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 1.5, 8, 24), patientMat);
  body.rotation.x = Math.PI / 2;
  body.position.set(0, -0.36, 0.1);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 32, 24), patientMat);
  head.position.set(0, -0.34, -0.95);
  const pillow = new THREE.Mesh(new RoundedBoxGeometry(0.5, 0.08, 0.35, 3, 0.04), purpleMat);
  pillow.position.set(0, -0.51, -0.98);
  sled.add(body, head, pillow);

  // ---------- Feixe de varredura ----------
  const scanMat = new THREE.MeshBasicMaterial({
    color: COLORS.scan, transparent: true, opacity: 0.22, side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false,
  });
  const scanDisc = new THREE.Mesh(new THREE.CircleGeometry(R_IN - 0.03, 64), scanMat);
  gantry.add(scanDisc);
  const scanLine = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 0.012, 0.012),
    new THREE.MeshBasicMaterial({ color: COLORS.scan, toneMapped: false }),
  );
  gantry.add(scanLine);

  // ---------- Piso: sombra suave + ondas de pulso ----------
  const floorY = -1.82;
  const shadowTex = radialTexture('rgba(66,32,78,0.35)', 'rgba(66,32,78,0)');
  const shadow = new THREE.Mesh(
    new THREE.PlaneGeometry(6, 6),
    new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = floorY;
  root.add(shadow);

  const pulses = [];
  for (let i = 0; i < 3; i++) {
    const p = new THREE.Mesh(
      new THREE.RingGeometry(0.98, 1, 96),
      new THREE.MeshBasicMaterial({ color: COLORS.violet, transparent: true, opacity: 0, depthWrite: false }),
    );
    p.rotation.x = -Math.PI / 2;
    p.position.y = floorY + 0.01;
    p.userData.offset = i / 3;
    root.add(p);
    pulses.push(p);
  }

  // ---------- Monitor holográfico com ECG ----------
  const ecgCanvas = document.createElement('canvas');
  ecgCanvas.width = 512; ecgCanvas.height = 320;
  const ecgCtx = ecgCanvas.getContext('2d');
  const ecgTex = new THREE.CanvasTexture(ecgCanvas);
  ecgTex.colorSpace = THREE.SRGBColorSpace;
  ecgTex.anisotropy = 4;
  const monitor = new THREE.Group();
  const monitorFrame = new THREE.Mesh(new RoundedBoxGeometry(1.5, 0.96, 0.06, 3, 0.03), purpleMat);
  const monitorScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(1.42, 0.88),
    new THREE.MeshBasicMaterial({ map: ecgTex, toneMapped: false }),
  );
  monitorScreen.position.z = 0.032;
  monitor.add(monitorFrame, monitorScreen);
  monitor.position.set(-2.35, 1.0, 0.6);
  monitor.rotation.y = 0.45;
  root.add(monitor);
  const ecgHistory = new Float32Array(160).fill(0);

  // ---------- Chips de exames (interativos) ----------
  const chips = [];
  const chipPositions = [
    [2.35, 1.15, 0.3],
    [2.6, -0.25, 1.1],
    [-2.45, -0.45, 1.35],
    [1.35, 1.9, -0.8],
    [-1.25, 2.0, -0.6],
  ];
  const chipGeo = new RoundedBoxGeometry(0.72, 0.72, 0.14, 4, 0.09);
  EXAMS.forEach((exam, i) => {
    // RoundedBoxGeometry não tem grupos por face; a arte vai num plano frontal
    const faceMat = new THREE.MeshPhysicalMaterial({ map: chipTexture(exam), roughness: 0.3, clearcoat: 1 });
    const chip = new THREE.Group();
    const bodyMesh = new THREE.Mesh(chipGeo, shellMat);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), faceMat);
    face.position.z = 0.072;
    const rim = new THREE.Mesh(
      new THREE.TorusGeometry(0.44, 0.012, 8, 64),
      new THREE.MeshBasicMaterial({ color: COLORS.scan, transparent: true, opacity: 0, toneMapped: false }),
    );
    chip.add(bodyMesh, face, rim);
    chip.position.fromArray(chipPositions[i]);
    chip.userData = { exam, base: chip.position.clone(), phase: i * 1.3, hover: 0, rim };
    bodyMesh.userData.chip = chip;
    face.userData.chip = chip;
    root.add(chip);
    chips.push(chip);
  });

  // ---------- Partículas ----------
  const P_COUNT = isSmall ? 120 : 260;
  const pGeo = new THREE.BufferGeometry();
  const pPos = new Float32Array(P_COUNT * 3);
  const pSpeed = new Float32Array(P_COUNT);
  for (let i = 0; i < P_COUNT; i++) {
    pPos[i * 3] = (Math.random() - 0.5) * 7;
    pPos[i * 3 + 1] = floorY + Math.random() * 4.5;
    pPos[i * 3 + 2] = (Math.random() - 0.5) * 5;
    pSpeed[i] = 0.08 + Math.random() * 0.22;
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  const particles = new THREE.Points(pGeo, new THREE.PointsMaterial({
    color: COLORS.violet, size: 0.035, sizeAttenuation: true, transparent: true, opacity: 0.55, depthWrite: false,
  }));
  root.add(particles);

  // ---------- Tooltip HTML ----------
  const tip = document.createElement('div');
  tip.className = 'hero3d__tip';
  tip.setAttribute('role', 'status');
  container.appendChild(tip);
  let tipTarget = null;

  function showTip(obj, html) {
    if (tipTarget !== obj) { tip.innerHTML = html; tipTarget = obj; }
    tip.classList.add('is-on');
  }
  function hideTip() { tip.classList.remove('is-on'); tipTarget = null; }

  // ---------- Interação ----------
  const pointer = new THREE.Vector2(0, 0);   // -1..1
  const look = new THREE.Vector2(0, 0);      // suavizado
  let pointerInside = false;
  let dragOffset = 0, dragVel = 0, dragging = false, lastX = 0, downX = 0, downY = 0;
  const raycaster = new THREE.Raycaster();
  let hoveredChip = null, gantryHover = false;

  function setPointer(e) {
    const r = container.getBoundingClientRect();
    pointer.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    pointer.y = -((e.clientY - r.top) / r.height) * 2 + 1;
  }

  const el = renderer.domElement;
  el.addEventListener('pointermove', (e) => {
    setPointer(e); pointerInside = true;
    if (dragging) {
      const dx = e.clientX - lastX; lastX = e.clientX;
      dragVel = dx * 0.006; dragOffset += dragVel;
    }
  });
  el.addEventListener('pointerleave', () => { pointerInside = false; if (!isTouch) hideTip(); });
  el.addEventListener('pointerdown', (e) => {
    setPointer(e); dragging = true; lastX = downX = e.clientX; downY = e.clientY; dragVel = 0;
  });
  el.addEventListener('pointercancel', () => { dragging = false; }); // rolagem vertical no mobile
  window.addEventListener('pointerup', (e) => {
    if (!dragging) return;
    dragging = false;
    const moved = Math.hypot(e.clientX - downX, e.clientY - downY);
    if (moved < 8 && e.target === el) handleTap();
  });

  function pick() {
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects([...chips.flatMap(c => c.children.slice(0, 2)), shell], false);
    return hits[0]?.object || null;
  }

  function handleTap() {
    const hit = pick();
    const chip = hit?.userData.chip;
    if (chip) {
      // 1º toque no mobile mostra o card; 2º toque (ou clique no desktop) abre WhatsApp
      if (!isTouch || hoveredChip === chip) {
        window.open(WHATS + encodeURIComponent(`Olá! Gostaria de agendar um exame de ${chip.userData.exam.nome}.`), '_blank', 'noopener');
      }
      hoveredChip = chip; gantryHover = false;
    } else if (hit === shell) {
      hoveredChip = null; gantryHover = true;
    } else {
      hoveredChip = null; gantryHover = false; hideTip();
    }
  }

  // ---------- Layout ----------
  function resize() {
    const w = container.clientWidth, h = container.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    // Enquadra a cena (≈6.4 x 5 unidades) em qualquer proporção: desktop largo ou mobile alto
    const tanHalf = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * 2;
    camera.userData.dist = Math.max(5 / tanHalf, 6.6 / (tanHalf * camera.aspect));
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(container);
  resize();

  // ---------- Loop ----------
  const clock = new THREE.Clock();
  let running = false, raf = 0, introT = 0, ecgAcc = 0, t = 0;
  // Debug para screenshots: ?shot=SEGUNDOS&hover=INDICE
  const qs = new URLSearchParams(location.search);
  const shot = qs.has('shot') ? parseFloat(qs.get('shot')) : null;
  const forceHover = qs.has('hover') ? chips[+qs.get('hover')] : null;
  if (shot !== null) { introT = 1; t = shot; }
  const camDir = new THREE.Vector3(0.55, 0.32, 1).normalize();
  const tmpV = new THREE.Vector3();

  function frame() {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), 0.05);
    if (shot === null) t += dt * speed;
    introT = Math.min(introT + dt / 1.6, 1);
    const intro = easeOutBack(introT);

    // Câmera (entrada suave + respiração)
    const dist = camera.userData.dist * (1.25 - 0.25 * easeOutCubic(introT));
    camera.position.copy(camDir).multiplyScalar(dist).add(CAM_TARGET);
    camera.position.y += Math.sin(t * 0.4) * 0.08;
    camera.lookAt(CAM_TARGET);

    // Parallax do mouse + arrasto com inércia
    if (!dragging) { dragVel *= 0.94; dragOffset += dragVel; dragOffset *= 0.985; }
    const tx = pointerInside && !isTouch ? pointer.x : Math.sin(t * 0.25) * 0.35;
    const ty = pointerInside && !isTouch ? pointer.y : 0;
    look.x += (tx - look.x) * 0.06;
    look.y += (ty - look.y) * 0.06;
    root.rotation.y = -0.35 + look.x * 0.32 + dragOffset;
    root.rotation.x = -look.y * 0.08;
    cursorLight.position.set(look.x * 3, 0.8 + look.y * 1.5, 2.6);

    // Entrada (escala)
    gantry.scale.setScalar(intro);
    tableRig.scale.setScalar(intro);
    pedestal.scale.setScalar(intro);
    monitor.scale.setScalar(easeOutBack(clamp01(introT * 1.4 - 0.3)));

    // Hover (desktop)
    if (!isTouch && pointerInside && !dragging) {
      const hit = pick();
      hoveredChip = hit?.userData.chip || null;
      gantryHover = hit === shell;
      el.style.cursor = hoveredChip ? 'pointer' : 'grab';
    }
    if (forceHover) hoveredChip = forceHover;

    // Ciclo da mesa: entra no túnel, escaneia, sai
    const cycle = (t % 9) / 9;
    let slide;
    if (cycle < 0.22) slide = 1 - easeInOut(cycle / 0.22);
    else if (cycle < 0.78) slide = 0;
    else slide = easeInOut((cycle - 0.78) / 0.22);
    sled.position.z = 0.55 + slide * 1.35;
    const scanning = cycle > 0.2 && cycle < 0.8;
    const scanBoost = gantryHover ? 1 : 0;

    // Feixe
    const sweep = Math.sin(t * (scanning ? 2.2 : 0.8) * (1 + scanBoost)) * (DEPTH / 2 + 0.05);
    scanDisc.position.z = sweep;
    scanLine.position.set(0, -0.15, sweep);
    scanMat.opacity = (scanning ? 0.26 : 0.08) + scanBoost * 0.15 + Math.sin(t * 8) * 0.03;
    scanLine.visible = scanning || gantryHover;

    // Anéis do túnel pulsando
    const glowPulse = 0.6 + Math.sin(t * 3) * 0.4;
    boreGlowF.material.color.setHex(COLORS.scan).multiplyScalar(0.6 + glowPulse * 0.6 + scanBoost * 0.6);
    boreGlowB.material.color.copy(boreGlowF.material.color);

    // LEDs em perseguição
    const head = (t * (scanning ? 22 : 9) * (1 + scanBoost)) % LED_COUNT;
    for (let i = 0; i < LED_COUNT; i++) {
      const d = (head - i + LED_COUNT) % LED_COUNT;
      const k = Math.max(0, 1 - d / 14);
      tmpColor.copy(LED_IDLE).lerp(LED_HOT, k);
      leds.setColorAt(i, tmpColor);
    }
    leds.instanceColor.needsUpdate = true;

    // Paciente "respira"
    body.scale.set(1, 1, 1 + Math.sin(t * 1.6) * 0.015);

    // Ondas no piso
    pulses.forEach((p) => {
      const k = (t * 0.35 + p.userData.offset) % 1;
      p.scale.setScalar(1 + k * 2.2);
      p.material.opacity = (1 - k) * 0.35 * (scanning ? 1 : 0.5);
    });

    // Partículas subindo
    const arr = pGeo.attributes.position.array;
    for (let i = 0; i < P_COUNT; i++) {
      arr[i * 3 + 1] += pSpeed[i] * dt * speed;
      if (arr[i * 3 + 1] > 2.8) arr[i * 3 + 1] = floorY;
    }
    pGeo.attributes.position.needsUpdate = true;

    // Chips: flutuam, olham para a câmera, reagem ao hover
    chips.forEach((c, i) => {
      const u = c.userData;
      const target = c === hoveredChip ? 1 : 0;
      u.hover += (target - u.hover) * 0.15;
      const s = clamp01(introT * 1.6 - 0.4 - i * 0.08);
      c.scale.setScalar(easeOutBack(s) * (1 + u.hover * 0.28));
      c.position.set(
        u.base.x,
        u.base.y + Math.sin(t * 1.1 + u.phase) * 0.12 + u.hover * 0.1,
        u.base.z + u.hover * 0.35,
      );
      c.lookAt(camera.position);
      c.rotateZ(Math.sin(t * 0.8 + u.phase) * 0.06 * (1 - u.hover));
      u.rim.material.opacity = u.hover * 0.9;
      u.rim.scale.setScalar(1 + Math.sin(t * 6) * 0.03 * u.hover);
    });

    // Tooltip
    if (hoveredChip) {
      const ex = hoveredChip.userData.exam;
      placeTip(hoveredChip.position);
      showTip(hoveredChip, `<strong>${ex.nome}</strong><span>${ex.desc}</span><em>${isTouch ? 'Toque de novo para agendar' : 'Clique para agendar'} →</em>`);
    } else if (gantryHover) {
      placeTip(tmpV.set(0, 1.7, 0));
      showTip(shell, '<strong>Ressonância Magnética</strong><span>Equipamento de última geração, laudos precisos.</span>');
    } else if (tipTarget) {
      hideTip();
    }

    // Monitor ECG (30 fps é suficiente)
    ecgAcc += dt;
    if (ecgAcc > 1 / 30) { ecgAcc = 0; drawEcg(scanning, cycle); }
    monitor.position.y = 1.0 + Math.sin(t * 0.9) * 0.06;

    renderer.render(scene, camera);
  }

  function placeTip(worldPos) {
    tmpV.copy(worldPos).applyMatrix4(root.matrixWorld).project(camera); // posições estão no espaço do root
    const x = (tmpV.x * 0.5 + 0.5) * container.clientWidth;
    const y = (-tmpV.y * 0.5 + 0.5) * container.clientHeight;
    const cx = clamp(x, 116, container.clientWidth - 116);
    const above = y - 60 - tip.offsetHeight > 0; // sem espaço em cima? abre para baixo
    tip.classList.toggle('is-below', !above);
    tip.style.transform = above
      ? `translate(${cx}px, ${y - 60}px) translate(-50%, -100%)`
      : `translate(${cx}px, ${y + 60}px) translate(-50%, 0)`;
  }

  function drawEcg(scanning, cycle) {
    const c = ecgCtx, W = 512, H = 320;
    const g = c.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#1f0f27'); g.addColorStop(1, '#3a1b47');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    // grade
    c.strokeStyle = 'rgba(201,167,224,0.08)'; c.lineWidth = 1;
    for (let x = 0; x < W; x += 32) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); }
    for (let y = 0; y < H; y += 32) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    // novo ponto de ECG
    const beat = (t * 1.2) % 1;
    let v = Math.sin(t * 9) * 0.02;
    if (beat > 0.10 && beat < 0.14) v = 0.15;
    else if (beat > 0.18 && beat < 0.2) v = -0.2;
    else if (beat > 0.2 && beat < 0.23) v = 1;
    else if (beat > 0.23 && beat < 0.26) v = -0.35;
    else if (beat > 0.4 && beat < 0.5) v = 0.22 * Math.sin((beat - 0.4) * Math.PI * 10);
    ecgHistory.copyWithin(0, 1); ecgHistory[ecgHistory.length - 1] = v;
    c.strokeStyle = '#2ec5d3'; c.lineWidth = 4; c.shadowColor = '#2ec5d3'; c.shadowBlur = 14;
    c.beginPath();
    for (let i = 0; i < ecgHistory.length; i++) {
      const x = 24 + (i / (ecgHistory.length - 1)) * (W - 48);
      const y = 150 - ecgHistory[i] * 90;
      i ? c.lineTo(x, y) : c.moveTo(x, y);
    }
    c.stroke(); c.shadowBlur = 0;
    // textos
    c.fillStyle = '#c9a7e0'; c.font = '700 26px Inter, system-ui, sans-serif';
    c.fillText('VILLAGE · IMAGEM', 24, 40);
    c.fillStyle = '#ffffff'; c.font = '800 46px Inter, system-ui, sans-serif';
    c.textAlign = 'right'; c.fillText(`${72 + Math.round(Math.sin(t * 0.5) * 3)} bpm`, W - 24, 50); c.textAlign = 'left';
    // barra de progresso do exame
    const prog = scanning ? clamp01((cycle - 0.2) / 0.6) : cycle < 0.2 ? 0 : 1;
    c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(24, 262, W - 48, 14);
    c.fillStyle = '#2ec5d3'; c.fillRect(24, 262, (W - 48) * prog, 14);
    c.fillStyle = '#ffffff'; c.font = '700 30px Inter, system-ui, sans-serif';
    c.fillText(scanning ? `Escaneando… ${Math.round(prog * 100)}%` : prog >= 1 ? 'Exame concluído ✓' : 'Posicionando paciente', 24, 248);
    ecgTex.needsUpdate = true;
  }

  // Só renderiza quando visível (economia de bateria)
  function start() { if (!running) { running = true; clock.getDelta(); frame(); } }
  function stop() { running = false; cancelAnimationFrame(raf); }
  new IntersectionObserver(([e]) => (e.isIntersecting && !document.hidden ? start() : stop()), { threshold: 0.05 })
    .observe(container);
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));

  container.classList.add('is-ready');
}

// ---------- Helpers ----------
function chipTexture(exam) {
  const S = 256;
  const c = document.createElement('canvas'); c.width = c.height = S;
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  drawChip(c.getContext('2d'), S, exam);
  // Redesenha quando a Inter terminar de carregar (canvas não espera a webfont)
  document.fonts?.load('800 40px Inter').then(() => { drawChip(c.getContext('2d'), S, exam); tex.needsUpdate = true; });
  return tex;
}

function drawChip(x, S, exam) {
  x.clearRect(0, 0, S, S);
  x.fillStyle = '#ffffff'; x.fillRect(0, 0, S, S);
  const g = x.createLinearGradient(0, 0, S, S);
  g.addColorStop(0, '#7b3fa0'); g.addColorStop(1, '#42204e');
  x.fillStyle = g;
  x.beginPath(); x.arc(S / 2, 96, 64, 0, Math.PI * 2); x.fill();
  x.strokeStyle = 'rgba(46,197,211,0.9)'; x.lineWidth = 6;
  x.beginPath(); x.arc(S / 2, 96, 75, -Math.PI * 0.8, Math.PI * 0.1); x.stroke();
  x.fillStyle = '#ffffff'; x.font = '800 52px Inter, system-ui, sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(exam.sigla, S / 2, 98);
  x.fillStyle = '#42204e';
  let fs = 40;
  do { x.font = `800 ${fs}px Inter, system-ui, sans-serif`; fs -= 2; } while (x.measureText(exam.nome).width > S - 24);
  x.fillText(exam.nome, S / 2, 212);
}

function radialTexture(inner, outer) {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, inner); g.addColorStop(1, outer);
  x.fillStyle = g; x.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
}

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const clamp01 = (v) => clamp(v, 0, 1);
const easeOutCubic = (x) => 1 - (1 - x) ** 3;
const easeInOut = (x) => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
function easeOutBack(x) {
  x = clamp01(x);
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2;
}
