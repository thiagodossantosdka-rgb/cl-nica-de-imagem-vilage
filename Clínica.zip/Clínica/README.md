# Site da Clínica de Imagem Village

Site estático, com uma maquete 3D animada da clínica feita em Three.js, pronto para publicar na Vercel.

## Estrutura

```
├── public/                  ← tudo que vai para o ar
│   ├── index.html
│   ├── 404.html
│   ├── favicon.svg · robots.txt · sitemap.xml
│   ├── css/style.css
│   ├── js/main.js           ← menu, WhatsApp, animações de rolagem
│   ├── js/hero3d.bundle.js  ← gerado pelo build (não editar)
│   └── assets/              ← logos, imagem de compartilhamento, imagem reserva do 3D
├── src/                     ← código-fonte da cena 3D
│   ├── hero3d.js            ← maquete da clínica (cena atual)
│   ├── hero3d-entry.js
│   └── hero3d-ressonancia.js ← versão anterior (aparelho de ressonância)
├── package.json             ← build com esbuild
└── vercel.json              ← build, pasta de saída, cache e headers de segurança
```

## Publicar na Vercel

**Opção A, pelo GitHub (recomendado, cada `git push` publica sozinho):**
1. Crie um repositório no GitHub e envie esta pasta (o `node_modules/` já está no `.gitignore`).
2. Na Vercel: **Add New → Project → Import** e escolha o repositório.
3. Não mude nada: o `vercel.json` já define o build (`npm run build`) e a pasta de saída (`public`). Clique em **Deploy**.

**Opção B, pelo terminal:**
```sh
npx vercel          # primeira vez: faz login e cria o projeto (preview)
npx vercel --prod   # publica em produção
```

**Domínio próprio:** em *Project → Settings → Domains*, adicione `clinicavillage.com.br` e siga as instruções de DNS.
Se usar outro domínio, troque `clinicavillage.com.br` em `public/index.html` (canonical e og), `robots.txt` e `sitemap.xml`.

## Desenvolvimento

```sh
npm install
npm run build   # regenera public/js/hero3d.bundle.js depois de editar src/
npm run dev     # build + servidor em http://localhost:3000
```

Depois de alterar CSS ou JS, mude o `?v=20261014` no `index.html` para os visitantes receberem a versão nova sem cache.
