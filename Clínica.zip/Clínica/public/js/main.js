document.documentElement.classList.add('js');
(function () {
  var WA = 'https://api.whatsapp.com/send?phone=5561996104545&text=';

  // Todos os links [data-wa] abrem o WhatsApp com mensagem pronta
  document.querySelectorAll('[data-wa]').forEach(function (a) {
    a.href = WA + encodeURIComponent(a.getAttribute('data-wa'));
    a.target = '_blank';
    a.rel = 'noopener';
  });

  // Formulário -> WhatsApp (sem backend)
  var form = document.getElementById('lead-form');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var d = new FormData(form);
    var msg = 'Olá! Meu nome é ' + d.get('nome') + ' e gostaria de agendar: ' + d.get('servico') + '.';
    window.open(WA + encodeURIComponent(msg), '_blank', 'noopener');
  });

  // Menu mobile
  var burger = document.querySelector('.burger');
  var nav = document.getElementById('nav');
  burger.addEventListener('click', function () {
    var open = document.body.classList.toggle('menu-open');
    burger.setAttribute('aria-expanded', open);
  });
  nav.querySelectorAll('a').forEach(function (a) {
    a.addEventListener('click', function () { document.body.classList.remove('menu-open'); });
  });

  // Header com sombra ao rolar
  var header = document.querySelector('.header');
  addEventListener('scroll', function () {
    header.classList.toggle('is-scrolled', scrollY > 10);
  }, { passive: true });

  // Revelar ao rolar
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.15 });
    document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('is-in'); });
  }

  // Se o 3D não carregar (sem internet/CDN), mostra a versão estática
  setTimeout(function () {
    var s = document.getElementById('hero3d');
    if (s && !s.classList.contains('is-ready')) s.classList.add('is-fallback');
  }, 8000);
})();
